
url <- "https://d396qusza40orc.cloudfront.net/getdata%2Fdata%2FDATA.gov_NGAP.xlsx"


download.file(url, destfile = "./naturalg.xlsx", method = "curl")
dateDownloaded <- date()


naturalG <- read.xlsx("./naturalg.xlsx", sheetIndex = 1 )
